export const JOB_SOURCES = [
  {
    id: "1359dac4-a397-4461-b747-382706dcbe79",
    label: "Indeed",
    value: "indeed",
  },
  {
    id: "a483e678-6e3d-41cf-8c6f-6540b02551eb",
    label: "Linkedin",
    value: "linkedin",
  },
  {
    id: "8d941ed0-6882-4d88-b985-d614e9828576",
    label: "Monster",
    value: "monster",
  },
  {
    id: "49a9a222-d5ac-452b-88d8-7258e2e58c07",
    label: "Glassdoor",
    value: "glassdoor",
  },
  {
    id: "08642cf8-29f5-4535-ad58-63edbbace13f",
    label: "Company Career page",
    value: "careerpage",
  },
  {
    id: "090eefe1-2f99-46d1-925f-d59e0e8f072c",
    label: "Google",
    value: "google",
  },
  {
    id: "c0ae0c56-beed-471c-b7d3-4eb1f732fe8f",
    label: "ZipRecruiter",
    value: "ziprecruiter",
  },
  {
    id: "108537a8-1d84-4bc3-8820-4a1cd71c5ccf",
    label: "Job Street",
    value: "jobstreet",
  },
  {
    id: "ddd8aa2e-37c1-4dc8-b370-a844ff1ad82c",
    label: "Other",
    value: "other",
  },
];
