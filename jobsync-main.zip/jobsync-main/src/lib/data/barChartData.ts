export const barChartData = {
  data: [
    {
      day: "Mon",
      jobs: 14,
    },
    {
      day: "Tues",
      jobs: 13,
    },
    {
      day: "Wed",
      jobs: 15,
    },
    {
      day: "Thurs",
      jobs: 16,
    },
    {
      day: "Fri",
      jobs: 17,
    },
    {
      day: "Sat",
      jobs: 20,
    },
    {
      day: "Sun",
      jobs: 25,
    },
  ],
};
