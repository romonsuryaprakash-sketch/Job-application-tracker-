export type AlertDialog = {
  openState: boolean;
  title?: string;
  description?: string;
  deleteAction: boolean;
  itemId?: string;
};
