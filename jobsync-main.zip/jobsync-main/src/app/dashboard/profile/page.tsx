import ProfileContainer from "@/components/profile/ProfileContainer";
import React from "react";

function Profile() {
  return (
    <div className="col-span-3">
      <ProfileContainer />
    </div>
  );
}

export default Profile;
