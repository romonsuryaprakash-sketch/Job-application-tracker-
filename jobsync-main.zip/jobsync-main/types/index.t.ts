// declare interface HeaderProps {
//   type?: "title" | "greeting";
//   title: string;
//   subtext: string;
//   user?: string;
// }

// declare type User = {
//   $id: string;
//   email: string;
//   name: string;
// };

// declare interface SidebarProps {
//   user: User;
// }
