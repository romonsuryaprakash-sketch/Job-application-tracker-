import PropTypes from "prop-types";

const AvatarShape = {
  name: PropTypes.string,
  avatarURL: PropTypes.string,
};

export { AvatarShape };
