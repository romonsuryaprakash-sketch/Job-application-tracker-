import PropTypes from "prop-types";

const backgroundShape = {
  image: PropTypes.node.isRequired,
};

export { backgroundShape };
