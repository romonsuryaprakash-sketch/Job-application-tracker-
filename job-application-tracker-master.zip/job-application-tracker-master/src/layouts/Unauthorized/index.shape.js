import PropTypes from "prop-types";

const unauthorizedShape = {
  children: PropTypes.node.isRequired,
};

export { unauthorizedShape };
