export default [
  {
    name: "name",
    type: "text",
    inputProps: {
      label: "Name",
      placeholder: "Enter column name",
    },
  },
];
