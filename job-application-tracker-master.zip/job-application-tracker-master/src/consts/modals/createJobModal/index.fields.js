export default [
  {
    name: "name",
    type: "text",
    inputProps: {
      label: "Name",
      placeholder: "Enter job name",
    },
  },
  {
    name: "companyName",
    type: "text",
    inputProps: {
      label: "Company Name",
      placeholder: "Enter company name",
    },
  },
];
