const LS_TOKEN_NAME = "token";
const LS_USER_NAME = "user";

export { LS_TOKEN_NAME, LS_USER_NAME };
